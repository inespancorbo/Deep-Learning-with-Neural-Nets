time python rnn_charlm.py -epochs 5 -L2 0.001 -train ./data/PaulGraham.txt -dev ./data/write.txt -embed 10
